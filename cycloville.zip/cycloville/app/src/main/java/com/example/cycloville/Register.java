package com.example.cycloville;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;

import okhttp3.Call;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Register extends AppCompatActivity {

    EditText firstname,secondname,email,phone,password;
    Button register,login;
    String firstName,secondName,Email,Phone,Password;
    HashMap<String, String> params = new HashMap<String, String>();
    OkHttpClient client = new OkHttpClient();
    String resp = null;
    String url = "http://192.168.0.159/registration";
    StringBuilder sbParams = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        firstname = findViewById(R.id.etFirstName);
        secondname = findViewById(R.id.etSecondName);
        email = findViewById(R.id.etEmail);
        phone  = findViewById(R.id.etPhone);
        register = findViewById(R.id.btnReg);
        login = findViewById(R.id.btnSignIn);
        password = findViewById(R.id.etPassword);



        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Register.this, Login.class);
                startActivity(i);

            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Thread thread = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        try  {
                            sendData();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });

                thread.start();


            }
        });
    }

    private void sendData() throws IOException, JSONException {
        firstName = firstname.getText().toString();
        secondName = secondname.getText().toString();
        Email = email.getText().toString();
        Phone = phone.getText().toString();
        Password = MD5.encrypt(password.getText().toString());



        RequestBody formBody = new FormBody.Builder()
                .add("first_name", firstName)
                .add("second_name", secondName)
                .add("email", Email)
                .add("phone", Phone)
                .add("password", Password)
                .build();

        System.out.println(formBody.toString());

        Request request = new Request.Builder()
                .url(url + "/register.php")
                .post(formBody)
                .build();

        Call call = client.newCall(request);
        Response response = call.execute();
        resp = response.body().string();

        System.out.println(resp);

        JSONObject jObj = new JSONObject(resp);
        boolean error = jObj.getBoolean("error");

        if (!error) {
            String user = jObj.getJSONObject("user").getString("name");
            Toast.makeText(getApplicationContext(), "Hi " + user +", You are successfully Added!", Toast.LENGTH_SHORT).show();

            // Launch login activity
            Intent intent = new Intent(
                    Register.this,
                    Login.class);
            startActivity(intent);
            finish();
        } else {

            String errorMsg = jObj.getString("error_msg");
            Toast.makeText(getApplicationContext(),
                    errorMsg, Toast.LENGTH_LONG).show();
        }

    }

}
