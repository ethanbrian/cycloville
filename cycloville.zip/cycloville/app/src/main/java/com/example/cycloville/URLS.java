package com.example.cycloville;

public class URLS
{
    private static final String URL_ROOT = "http:// 192.168.0.65/myapi/api.php?action=";
    public static final String URL_LOGIN= URL_ROOT + "login";
}
