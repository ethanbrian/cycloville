package com.example.cycloville;

import java.util.Date;

public class User
{
    private String first_name, email;

    public User( String first_name, String email) {

        this.first_name = first_name;
        this.email = email;
    }
    public String getFirst_name() {
        return first_name;
    }
    public String getEmail() {
        return email;
    }


}
