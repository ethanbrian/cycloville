package com.example.cycloville;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;

public class viewProduct extends AppCompatActivity {

    private static final String URL_PRODUCTS = "http://192.168.101.1/MyApi/Api.php";

    //a list to store all the products
    List<Product> productList;

    Button edit, delete;

    //the recyclerview
    RecyclerView recyclerView;
    String url = "http://192.168.0.65/registration";
    OkHttpClient client = new OkHttpClient();
    String resp = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_product);

        edit = findViewById(R.id.btnEdit);

        recyclerView = findViewById(R.id.recylcerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //initializing the productlist
        productList = new ArrayList<>();

        //this method will fetch and parse json
        //to display it in recyclerview
        loadProducts();



        //attaching click listener
        findViewById(R.id.btnDelete).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //calling this method to show our android custom alert dialog
                showCustomDialog();


            }
        });

        //attaching click listener
        findViewById(R.id.buttonYes).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //calling this method to show our android custom alert dialog
                Thread thread = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        try  {
                            DeleteProduct();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });


                thread.start();

            }
        });

        //attaching click listener
        findViewById(R.id.buttonNo).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(viewProduct.this, Dashboard.class);
                startActivity(i);
            }
        });



        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(viewProduct.this, editProduct.class);
                startActivity(i);
            }
        });


    }


    private void loadProducts() {

        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL_PRODUCTS,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            //converting the string to json array object
                            JSONArray array = new JSONArray(response);

                            //traversing through all the object
                            for (int i = 0; i < array.length(); i++) {

                                //getting product object from json array
                                JSONObject product = array.getJSONObject(i);

                                //adding the product to product list
                                productList.add(new Product(
                                        product.getInt("p_id"),
                                        product.getString("name"),
                                        product.getString("desc"),
                                        product.getDouble("price"),
                                        product.getString("image")
                                ));
                            }

                            //creating adapter object and setting it to recyclerview
                            ProductAdapter adapter = new ProductAdapter(viewProduct.this, productList);
                            recyclerView.setAdapter(adapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });

        //adding our stringrequest to queue
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void DeleteProduct() throws IOException {

        RequestBody formBody = new FormBody.Builder()
                .add("product", String.valueOf(productList))
                .build();

        System.out.println(formBody.toString());

        okhttp3.Request request = new okhttp3.Request.Builder()
                .url(url + "/deleteProducts.php")
                .post(formBody)
                .build();

        Call call = client.newCall(request);
        okhttp3.Response response = call.execute();
        resp = response.body().string();

        System.out.println(resp);

        if (resp.equals("Record Deleted Successfully")) {
            Intent i = new Intent(viewProduct.this, Dashboard.class);
            startActivity(i);
        }
    }

        private void showCustomDialog () {

            //before inflating the custom alert dialog layout, we will get the current activity viewgroup
            ViewGroup viewGroup = findViewById(android.R.id.content);

            //then we will inflate the custom alert dialog xml that we created
            View dialogView = LayoutInflater.from(this).inflate(R.layout.mydialog, viewGroup, false);


            //Now we need an AlertDialog.Builder object
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            //setting the view of the builder to our custom view that we already inflated
            builder.setView(dialogView);

            //finally creating the alert dialog and displaying it
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }

}

