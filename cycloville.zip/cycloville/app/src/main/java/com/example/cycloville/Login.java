package com.example.cycloville;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import okhttp3.Call;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Login extends AppCompatActivity {

    String FinalHttpData = "";
    String Result;
    BufferedWriter bufferedWriter;
    OutputStream outputStream;
    BufferedReader bufferedReader;
    StringBuilder stringBuilder = new StringBuilder();
    Login login;
    String Email, Password;
    String resp = null;
    OkHttpClient client = new OkHttpClient();
    String url = "http://192.168.0.65/registration";

    Button Signin;
    PrefManager pref;
    MD5 md;

    EditText etEmail, etPassword;

    ProgressDialog progressDialog;
    HashMap<String, String> hashMap = new HashMap<>();
    public static final String UserEmail = "";
    String PasswordHolder, EmailHolder;
    Boolean CheckEditText;
    String finalResult;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Signin = findViewById(R.id.btnSignIn);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);


//
        Signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Thread thread = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        try {
                            loginUser();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });

                thread.start();


            }
        });


    }

    private void validateInputs() {
    }

    private void loadDashboard() {
        Intent i = new Intent(getApplicationContext(), Dashboard.class);
        startActivity(i);
        finish();

    }


    private void loginUser() throws IOException, JSONException {

        Email = etEmail.getText().toString();

        Password = MD5.encrypt(etPassword.getText().toString());


        RequestBody formBody = new FormBody.Builder()
                .add("email", Email)
                .add("password", Password)
                .build();
        System.out.println(formBody.toString());

        Request request = new Request.Builder()
                .url(url + "/login.php")
                .post(formBody)
                .build();

        Call call = client.newCall(request);
        Response response = call.execute();
        resp = response.body().string();

        System.out.println(resp);
        JSONObject jObj = new JSONObject(resp);
        boolean error = jObj.getBoolean("error");
        if (!error) {
            String user = jObj.getJSONObject("user").getString("name");
            // Launch User activity
            Intent intent = new Intent(
                    Login.this,
                    Dashboard.class);
            intent.putExtra("username", user);
            startActivity(intent);
            finish();


        }else  {

            String errorMsg = jObj.getString("error_msg");
            Toast.makeText(getApplicationContext(),
                    errorMsg, Toast.LENGTH_LONG).show();
        }
    }
}
