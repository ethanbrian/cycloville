package com.example.cycloville;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import okhttp3.Call;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class editProduct extends AppCompatActivity {

    String url = "http://192.168.0.65/registration";
    OkHttpClient client = new OkHttpClient();
    EditText inputName;
    EditText inputPrice;
    EditText inputDesc;
    private ImageView imageView;
    String name,description;
    String price;
    String resp = null;
    String uploadImage;
    private Bitmap bitmap;
    private Uri filePath;

    private int PICK_IMAGE_REQUEST = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_product);

        // Edit Text
        inputName = (EditText) findViewById(R.id.inputName);
        inputPrice = (EditText) findViewById(R.id.inputPrice);
        inputDesc = (EditText) findViewById(R.id.inputDesc);
        imageView = (ImageView) findViewById(R.id.imageView);

        // Create button
        Button btnEditProduct = (Button) findViewById(R.id.btnCreateProduct);
        Button uploadImage = (Button) findViewById(R.id.uploadImage);

        btnEditProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Thread thread = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        try  {
                            sendData();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });

                thread.start();

            }
        });

        uploadImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileChooser();


            }
        });


    }

    public String getStringImage(Bitmap bmp){
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;
    }

    private void showFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {

            filePath = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                imageView.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void sendData() throws IOException {
        name= inputName.getText().toString();
        description = inputDesc.getText().toString();
        price = inputPrice.getText().toString();
        uploadImage = getStringImage(bitmap);


        RequestBody formBody = new FormBody.Builder()
                .add("name", name)
                .add("description", description)
                .add("price", price)
                .add("uploadImage", uploadImage)
                .build();

        System.out.println(formBody.toString());

        Request request = new Request.Builder()
                .url(url + "/updateProducts.php")
                .post(formBody)
                .build();

        Call call = client.newCall(request);
        Response response = call.execute();
        resp = response.body().string();

        System.out.println(resp);

        if (resp.equals("Record Updated Successfully"))
        {
            Intent i = new Intent(editProduct.this, viewProduct.class);
            startActivity(i);
        }

    }
}
